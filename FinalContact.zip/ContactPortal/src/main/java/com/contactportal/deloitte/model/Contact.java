package com.contactportal.deloitte.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "hr", name = "contacts")
public class Contact implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	private int contactId;
	@Column
	private String contactName;
	@Column
	private String contactNumber;
	@Column
	private String contactMail;
  @Column 
  private String contactAddress;
public int getContactId() {
	return contactId;
}
public void setContactId(int contactId) {
	this.contactId = contactId;
}
public String getContactName() {
	return contactName;
}
public void setContactName(String contactName) {
	this.contactName = contactName;
}
public String getContactNumber() {
	return contactNumber;
}
public void setContactNumber(String contactNumber) {
	this.contactNumber = contactNumber;
}
public String getContactMail() {
	return contactMail;
}
public void setContactMail(String contactMail) {
	this.contactMail = contactMail;
}
public String getContactAddress() {
	return contactAddress;
}
public void setContactAddress(String contactAddress) {
	this.contactAddress = contactAddress;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((contactAddress == null) ? 0 : contactAddress.hashCode());
	result = prime * result + contactId;
	result = prime * result + ((contactMail == null) ? 0 : contactMail.hashCode());
	result = prime * result + ((contactName == null) ? 0 : contactName.hashCode());
	result = prime * result + ((contactNumber == null) ? 0 : contactNumber.hashCode());
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Contact other = (Contact) obj;
	if (contactAddress == null) {
		if (other.contactAddress != null)
			return false;
	} else if (!contactAddress.equals(other.contactAddress))
		return false;
	if (contactId != other.contactId)
		return false;
	if (contactMail == null) {
		if (other.contactMail != null)
			return false;
	} else if (!contactMail.equals(other.contactMail))
		return false;
	if (contactName == null) {
		if (other.contactName != null)
			return false;
	} else if (!contactName.equals(other.contactName))
		return false;
	if (contactNumber == null) {
		if (other.contactNumber != null)
			return false;
	} else if (!contactNumber.equals(other.contactNumber))
		return false;
	return true;
}
@Override
public String toString() {
	return "Contacts [contactId=" + contactId + ", contactName=" + contactName + ", contactNumber=" + contactNumber
			+ ", contactMail=" + contactMail + ", contactAddress=" + contactAddress + "]";
}
public Contact(int contactId, String contactName, String contactNumber, String contactMail, String contactAddress) {
	super();
	this.contactId = contactId;
	this.contactName = contactName;
	this.contactNumber = contactNumber;
	this.contactMail = contactMail;
	this.contactAddress = contactAddress;
}
public Contact() {
	// TODO Auto-generated constructor stub
}

	
}