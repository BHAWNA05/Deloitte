package com.contactportal.deloitte.service;

import com.contactportal.deloitte.model.User;

public interface UserService {

	public void addUser(User user);
	
}
