package assignmentweek2;

public class Addition extends Arithmetic {

	

	@Override
	 int calculate(int num1, int num2) {
		// TODO Auto-generated method stub
		System.out.println("The addition of two numbers is :");
		return num1+num2;
		
	}

}
