package assignmentweek2;

public abstract class Arithmetic {
 


 abstract int calculate(int num1,int num2);
}
