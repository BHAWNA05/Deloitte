package assignmentweek2;

public class Division extends Arithmetic {

	@Override
	int calculate(int num1, int num2) {
		// TODO Auto-generated method stub
		System.out.println("The Division of two numbers is :");
		return num1/num2;	
	}

}
